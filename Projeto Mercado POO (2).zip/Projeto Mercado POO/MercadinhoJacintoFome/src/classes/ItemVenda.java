package classes;

public class ItemVenda extends Produto {
    
    private double valorTotalProduto;
    
    public void setValorTotalProduto(double valorTotalProduto) {
        this.valorTotalProduto = valorTotalProduto;
    }
    
    public double getValorTotalProduto() {
        return valorTotalProduto;
    }
}
